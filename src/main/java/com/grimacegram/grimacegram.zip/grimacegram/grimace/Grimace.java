package com.grimacegram.grimacegram.grimace;

import com.grimacegram.grimacegram.model.User;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;

@Data
@Entity
public class Grimace {
    @Id
    @GeneratedValue
    private long id;

    @NotNull
    @Size(min = 10, max = 5000)
    @Column(length = 5000)
    private String content;

    @Temporal(TemporalType.TIMESTAMP)
    private Date timestamp;




    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_user_id")
    private User user;
}
