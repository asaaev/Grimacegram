package com.grimacegram.grimacegram.repository;

import com.grimacegram.grimacegram.grimace.Grimace;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GrimaceRepository extends JpaRepository<Grimace, Long> {

}
